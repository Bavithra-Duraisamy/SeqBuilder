package testcases;

import java.io.IOException;
import org.testng.annotations.Test;
import base.BaseClass;
import pages.LoginPage;

public class CreateManualSequence extends BaseClass {

	
	
	@Test
	public void createManualSequence() throws IOException {
		LoginPage lp = new LoginPage();
		lp.clickLoginButton()
		.verifyTitle()
		.clickNewSequenceButton()
		.clickCreateFromScratch()
		.enterSequenceName("Email Manual Sequence 1")
		.clickAddAction()
		.selectEmailAction()
		.enterSubject("Subject 1")
		.enterEmailBody("Email body 1")
		.clickSaveButton()
		.verifyMissingDataIconIsNotDisplayed()
		.clickLaunchButton()
		.verifyLeadsDashboard();
	}
}
