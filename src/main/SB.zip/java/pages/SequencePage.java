package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class SequencePage extends BaseClass {

	public SequencePage clickNewSequenceButton() {
		driver.findElement(By.xpath("//span[text()='New sequence']")).click();
		return this;
	}

	public SequencePage clickCreateFromScratch() {
		driver.findElement(By.xpath("//span[text()='Create from Scratch']")).click();
		return this;
	}

	public SequencePage enterSequenceName(String seqName) {
		driver.findElement(By.xpath("//div[@id='app-header']/div/div/input")).sendKeys(seqName);
		return this;
	}

	public SequencePage clickAddAction() {
		driver.findElement(By.xpath("//p[text()='Add action']")).click();
		return this;
	}

	public SequencePage selectEmailAction() {
		driver.findElement(By.xpath("//div[@data-type='email']")).click();
		return this;
	}

	public SequencePage enterSubject(String subject) {
		driver.findElement(By.xpath("//div[@id='id-email-subject']/div/div/div")).sendKeys(subject);
		return this;
	}

	public SequencePage enterEmailBody(String emailBody) {
		driver.findElement(By.xpath("//div[@id='id-email-body']/div/div/div")).sendKeys(emailBody);
		return this;
	}

	public SequencePage clickSaveButton() {
		driver.findElement(By.xpath("//button[text()='Save']")).click();
		return this;
	}

	public SequencePage verifyMissingDataIconIsNotDisplayed() {
		boolean iIcon = driver.findElement(By.xpath("//img[@data-tooltip-id='missing-data-']")).isDisplayed();
		if (iIcon) {
			System.out.println("All the required info has been provided.");
		}
		return this;
	}

	/*
	 * public SequencePage verifyGmailIsConnected() { boolean connectGmailButton =
	 * driver.findElement(By.xpath("//button[text()='Connect Now']")).isDisplayed();
	 * if (connectGmailButton) {
	 * System.out.println("Gmail is connected already!.."); } else {
	 * driver.findElement(By.xpath("//button[text()='Connect Now']")).click();
	 * driver.findElement(By.xpath("//p[text()='Gmail / G-suite']")).click(); }
	 * return this; }
	 */

	public CandidatesPage clickLaunchButton() {
		driver.findElement(By.xpath("//button[text()='Launch']")).click();
		return new CandidatesPage();
	}
}
